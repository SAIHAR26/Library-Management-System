import {useEffect,useState} from 'react';
import {getBooks,addBook,getStudents,addStudent,getBorrows,addBorrow} from './api';

export default function App(){
 const [books,setBooks]=useState([]);
 const [students,setStudents]=useState([]);
 const [borrows,setBorrows]=useState([]);

 const [title,setTitle]=useState("");
 const [name,setName]=useState("");

 useEffect(()=>{load();},[]);

 const load=async()=>{
  setBooks(await getBooks());
  setStudents(await getStudents());
  setBorrows(await getBorrows());
 };

 return(
  <div style={{padding:20}}>
   <h2>📚 Library Full App</h2>

   <h3>Add Book</h3>
   <input value={title} onChange={e=>setTitle(e.target.value)}/>
   <button onClick={async()=>{await addBook({title});load();}}>Add</button>

   <h3>Books</h3>
   {books.map(b=><div key={b._id}>{b.title}</div>)}

   <h3>Add Student</h3>
   <input value={name} onChange={e=>setName(e.target.value)}/>
   <button onClick={async()=>{await addStudent({name});load();}}>Add</button>

   <h3>Students</h3>
   {students.map(s=><div key={s._id}>{s.name}</div>)}

   <h3>Borrow Records</h3>
   {borrows.map(b=><div key={b._id}>{b.studentId} borrowed {b.bookId}</div>)}
  </div>
 );
}
