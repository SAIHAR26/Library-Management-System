const API="http://localhost:5000/api";

export const getBooks=()=>fetch(`${API}/books`).then(r=>r.json());
export const addBook=(d)=>fetch(`${API}/books`,{method:"POST",headers:{'Content-Type':'application/json'},body:JSON.stringify(d)});

export const getStudents=()=>fetch(`${API}/students`).then(r=>r.json());
export const addStudent=(d)=>fetch(`${API}/students`,{method:"POST",headers:{'Content-Type':'application/json'},body:JSON.stringify(d)});

export const getBorrows=()=>fetch(`${API}/borrow`).then(r=>r.json());
export const addBorrow=(d)=>fetch(`${API}/borrow`,{method:"POST",headers:{'Content-Type':'application/json'},body:JSON.stringify(d)});
