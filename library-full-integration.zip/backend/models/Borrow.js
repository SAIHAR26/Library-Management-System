const mongoose = require('mongoose');
module.exports = mongoose.model('Borrow', new mongoose.Schema({
 studentId:String, bookId:String, borrowed:String, due:String, returned:String,
 fine:Number, finePaid:Boolean
}));
