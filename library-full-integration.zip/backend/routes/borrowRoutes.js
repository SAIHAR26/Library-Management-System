const router = require('express').Router();
const Borrow = require('../models/Borrow');

router.get('/', async(req,res)=> res.json(await Borrow.find()));
router.post('/', async(req,res)=> res.json(await new Borrow(req.body).save()));

module.exports = router;
