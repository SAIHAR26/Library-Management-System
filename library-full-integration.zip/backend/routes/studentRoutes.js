const router = require('express').Router();
const Student = require('../models/Student');

router.get('/', async(req,res)=> res.json(await Student.find()));
router.post('/', async(req,res)=> res.json(await new Student(req.body).save()));

module.exports = router;
