const router = require('express').Router();
const Book = require('../models/Book');

router.get('/', async(req,res)=> res.json(await Book.find()));
router.post('/', async(req,res)=> res.json(await new Book(req.body).save()));

module.exports = router;
