const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

mongoose.connect('mongodb://127.0.0.1:27017/libraryDB')
.then(()=>console.log("MongoDB Connected"))
.catch(err=>console.log(err));

app.use('/api/books', require('./routes/bookRoutes'));
app.use('/api/students', require('./routes/studentRoutes'));
app.use('/api/borrow', require('./routes/borrowRoutes'));

app.listen(5000, ()=>console.log("Server running on port 5000"));
